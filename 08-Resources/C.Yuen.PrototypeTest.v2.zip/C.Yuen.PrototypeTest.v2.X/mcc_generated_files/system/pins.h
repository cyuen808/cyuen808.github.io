/**
 * Generated Pins header File
 * 
 * @file pins.h
 * 
 * @defgroup  pinsdriver Pins Driver
 * 
 * @brief This is generated driver header for pins. 
 *        This header file provides APIs for all pins selected in the GUI.
 *
 * @version Driver Version  3.1.1
*/

/*
� [2025] Microchip Technology Inc. and its subsidiaries.

    Subject to your compliance with these terms, you may use Microchip 
    software and any derivatives exclusively with Microchip products. 
    You are responsible for complying with 3rd party license terms  
    applicable to your use of 3rd party software (including open source  
    software) that may accompany Microchip software. SOFTWARE IS ?AS IS.? 
    NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY, APPLY TO THIS 
    SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT,  
    MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE. IN NO EVENT 
    WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, 
    INCIDENTAL OR CONSEQUENTIAL LOSS, DAMAGE, COST OR EXPENSE OF ANY 
    KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF 
    MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE 
    FORESEEABLE. TO THE FULLEST EXTENT ALLOWED BY LAW, MICROCHIP?S 
    TOTAL LIABILITY ON ALL CLAIMS RELATED TO THE SOFTWARE WILL NOT 
    EXCEED AMOUNT OF FEES, IF ANY, YOU PAID DIRECTLY TO MICROCHIP FOR 
    THIS SOFTWARE.
*/

#ifndef PINS_H
#define PINS_H

#include <xc.h>

#define INPUT   1
#define OUTPUT  0

#define HIGH    1
#define LOW     0

#define ANALOG      1
#define DIGITAL     0

#define PULL_UP_ENABLED      1
#define PULL_UP_DISABLED     0

// get/set RA2 aliases
#define HUB_LED_TRIS                 TRISAbits.TRISA2
#define HUB_LED_LAT                  LATAbits.LATA2
#define HUB_LED_PORT                 PORTAbits.RA2
#define HUB_LED_WPU                  WPUAbits.WPUA2
#define HUB_LED_OD                   ODCONAbits.ODCA2
#define HUB_LED_ANS                  ANSELAbits.ANSELA2
#define HUB_LED_SetHigh()            do { LATAbits.LATA2 = 1; } while(0)
#define HUB_LED_SetLow()             do { LATAbits.LATA2 = 0; } while(0)
#define HUB_LED_Toggle()             do { LATAbits.LATA2 = ~LATAbits.LATA2; } while(0)
#define HUB_LED_GetValue()           PORTAbits.RA2
#define HUB_LED_SetDigitalInput()    do { TRISAbits.TRISA2 = 1; } while(0)
#define HUB_LED_SetDigitalOutput()   do { TRISAbits.TRISA2 = 0; } while(0)
#define HUB_LED_SetPullup()          do { WPUAbits.WPUA2 = 1; } while(0)
#define HUB_LED_ResetPullup()        do { WPUAbits.WPUA2 = 0; } while(0)
#define HUB_LED_SetPushPull()        do { ODCONAbits.ODCA2 = 0; } while(0)
#define HUB_LED_SetOpenDrain()       do { ODCONAbits.ODCA2 = 1; } while(0)
#define HUB_LED_SetAnalogMode()      do { ANSELAbits.ANSELA2 = 1; } while(0)
#define HUB_LED_SetDigitalMode()     do { ANSELAbits.ANSELA2 = 0; } while(0)

// get/set RB0 aliases
#define MOTOR_FWD_TRIS                 TRISBbits.TRISB0
#define MOTOR_FWD_LAT                  LATBbits.LATB0
#define MOTOR_FWD_PORT                 PORTBbits.RB0
#define MOTOR_FWD_WPU                  WPUBbits.WPUB0
#define MOTOR_FWD_OD                   ODCONBbits.ODCB0
#define MOTOR_FWD_ANS                  ANSELBbits.ANSELB0
#define MOTOR_FWD_SetHigh()            do { LATBbits.LATB0 = 1; } while(0)
#define MOTOR_FWD_SetLow()             do { LATBbits.LATB0 = 0; } while(0)
#define MOTOR_FWD_Toggle()             do { LATBbits.LATB0 = ~LATBbits.LATB0; } while(0)
#define MOTOR_FWD_GetValue()           PORTBbits.RB0
#define MOTOR_FWD_SetDigitalInput()    do { TRISBbits.TRISB0 = 1; } while(0)
#define MOTOR_FWD_SetDigitalOutput()   do { TRISBbits.TRISB0 = 0; } while(0)
#define MOTOR_FWD_SetPullup()          do { WPUBbits.WPUB0 = 1; } while(0)
#define MOTOR_FWD_ResetPullup()        do { WPUBbits.WPUB0 = 0; } while(0)
#define MOTOR_FWD_SetPushPull()        do { ODCONBbits.ODCB0 = 0; } while(0)
#define MOTOR_FWD_SetOpenDrain()       do { ODCONBbits.ODCB0 = 1; } while(0)
#define MOTOR_FWD_SetAnalogMode()      do { ANSELBbits.ANSELB0 = 1; } while(0)
#define MOTOR_FWD_SetDigitalMode()     do { ANSELBbits.ANSELB0 = 0; } while(0)

// get/set RB1 aliases
#define MOTOR_REV_TRIS                 TRISBbits.TRISB1
#define MOTOR_REV_LAT                  LATBbits.LATB1
#define MOTOR_REV_PORT                 PORTBbits.RB1
#define MOTOR_REV_WPU                  WPUBbits.WPUB1
#define MOTOR_REV_OD                   ODCONBbits.ODCB1
#define MOTOR_REV_ANS                  ANSELBbits.ANSELB1
#define MOTOR_REV_SetHigh()            do { LATBbits.LATB1 = 1; } while(0)
#define MOTOR_REV_SetLow()             do { LATBbits.LATB1 = 0; } while(0)
#define MOTOR_REV_Toggle()             do { LATBbits.LATB1 = ~LATBbits.LATB1; } while(0)
#define MOTOR_REV_GetValue()           PORTBbits.RB1
#define MOTOR_REV_SetDigitalInput()    do { TRISBbits.TRISB1 = 1; } while(0)
#define MOTOR_REV_SetDigitalOutput()   do { TRISBbits.TRISB1 = 0; } while(0)
#define MOTOR_REV_SetPullup()          do { WPUBbits.WPUB1 = 1; } while(0)
#define MOTOR_REV_ResetPullup()        do { WPUBbits.WPUB1 = 0; } while(0)
#define MOTOR_REV_SetPushPull()        do { ODCONBbits.ODCB1 = 0; } while(0)
#define MOTOR_REV_SetOpenDrain()       do { ODCONBbits.ODCB1 = 1; } while(0)
#define MOTOR_REV_SetAnalogMode()      do { ANSELBbits.ANSELB1 = 1; } while(0)
#define MOTOR_REV_SetDigitalMode()     do { ANSELBbits.ANSELB1 = 0; } while(0)

// get/set RB4 aliases
#define USER_BUTTON_TRIS                 TRISBbits.TRISB4
#define USER_BUTTON_LAT                  LATBbits.LATB4
#define USER_BUTTON_PORT                 PORTBbits.RB4
#define USER_BUTTON_WPU                  WPUBbits.WPUB4
#define USER_BUTTON_OD                   ODCONBbits.ODCB4
#define USER_BUTTON_ANS                  ANSELBbits.ANSELB4
#define USER_BUTTON_SetHigh()            do { LATBbits.LATB4 = 1; } while(0)
#define USER_BUTTON_SetLow()             do { LATBbits.LATB4 = 0; } while(0)
#define USER_BUTTON_Toggle()             do { LATBbits.LATB4 = ~LATBbits.LATB4; } while(0)
#define USER_BUTTON_GetValue()           PORTBbits.RB4
#define USER_BUTTON_SetDigitalInput()    do { TRISBbits.TRISB4 = 1; } while(0)
#define USER_BUTTON_SetDigitalOutput()   do { TRISBbits.TRISB4 = 0; } while(0)
#define USER_BUTTON_SetPullup()          do { WPUBbits.WPUB4 = 1; } while(0)
#define USER_BUTTON_ResetPullup()        do { WPUBbits.WPUB4 = 0; } while(0)
#define USER_BUTTON_SetPushPull()        do { ODCONBbits.ODCB4 = 0; } while(0)
#define USER_BUTTON_SetOpenDrain()       do { ODCONBbits.ODCB4 = 1; } while(0)
#define USER_BUTTON_SetAnalogMode()      do { ANSELBbits.ANSELB4 = 1; } while(0)
#define USER_BUTTON_SetDigitalMode()     do { ANSELBbits.ANSELB4 = 0; } while(0)

/**
 * @ingroup  pinsdriver
 * @brief GPIO and peripheral I/O initialization
 * @param none
 * @return none
 */
void PIN_MANAGER_Initialize (void);

/**
 * @ingroup  pinsdriver
 * @brief Interrupt on Change Handling routine
 * @param none
 * @return none
 */
void PIN_MANAGER_IOC(void);


#endif // PINS_H
/**
 End of File
*/