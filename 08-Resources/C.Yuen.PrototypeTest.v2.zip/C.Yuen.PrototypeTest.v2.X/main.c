#include "mcc_generated_files/system/system.h"
#include "mcc_generated_files/system/pins.h"

#define BUTTON_PRESSED      0     // RB4 active-low
#define BUTTON_RELEASED     1

#define DEBOUNCE_MS         100
#define LONG_PRESS_MS       1000    // hold 1 sec
#define DOUBLE_PRESS_MS     350     // second press window
#define REVERSE_BLINK_MS    150

typedef enum {
    MODE_STOP,
    MODE_FORWARD,
    MODE_REVERSE
} MotorMode;

MotorMode mode = MODE_STOP;


// -------------------------------------------------
// MOTOR CONTROL FUNCTIONS
// -------------------------------------------------
void run_forward()
{
    MOTOR_FWD_SetHigh();
    MOTOR_REV_SetLow();
    HUB_LED_SetHigh();          // solid ON
    mode = MODE_FORWARD;
}

void run_reverse()
{
    MOTOR_FWD_SetLow();
    MOTOR_REV_SetHigh();
    mode = MODE_REVERSE;        // LED blinking in main loop
}

void run_stop()
{
    MOTOR_FWD_SetLow();
    MOTOR_REV_SetLow();
    HUB_LED_SetLow();           // LED OFF
    mode = MODE_STOP;
}


// -------------------------------------------------
// CLEAN DEBOUNCE: waits for stable button release
// -------------------------------------------------
void waitForRelease()
{
    while (USER_BUTTON_GetValue() == BUTTON_PRESSED)
        __delay_ms(10);

    __delay_ms(DEBOUNCE_MS);
}


// -------------------------------------------------
// EVENT ENGINE: returns 1/2/3 for single/double/long
// -------------------------------------------------
uint8_t getButtonEvent()
{
    // Wait for initial press
    if (USER_BUTTON_GetValue() != BUTTON_PRESSED)
        return 0;

    __delay_ms(DEBOUNCE_MS);

    // Confirm stable press
    if (USER_BUTTON_GetValue() != BUTTON_PRESSED)
        return 0;

    // Long-press detection
    uint16_t hold = 0;
    while (USER_BUTTON_GetValue() == BUTTON_PRESSED)
    {
        __delay_ms(10);
        hold += 10;

        if (hold >= LONG_PRESS_MS)
        {
            waitForRelease();
            return 3; // long press
        }
    }

    // Short press detected ? now wait for possible double-press
    waitForRelease();

    uint16_t timer = 0;
    while (timer < DOUBLE_PRESS_MS)
    {
        if (USER_BUTTON_GetValue() == BUTTON_PRESSED)
        {
            __delay_ms(DEBOUNCE_MS);
            waitForRelease();
            return 2;  // double press
        }

        __delay_ms(10);
        timer += 10;
    }

    return 1; // single press
}


// -------------------------------------------------
// MAIN PROGRAM LOOP
// -------------------------------------------------
void main(void)
{
    SYSTEM_Initialize();
    run_stop();  // safe startup

    uint16_t blinkTimer = 0;
    uint8_t ledState = 0;

    while (1)
    {
        uint8_t evt = getButtonEvent();

        if (evt == 1)
        {
            // SINGLE PRESS ? FORWARD
            run_forward();
        }
        else if (evt == 2)
        {
            // DOUBLE PRESS ? REVERSE
            run_reverse();
        }
        else if (evt == 3)
        {
            // LONG PRESS ? STOP
            run_stop();
        }

        // -----------------------------------------
        // BLINK LED IN REVERSE MODE
        // -----------------------------------------
        if (mode == MODE_REVERSE)
        {
            blinkTimer += 10;

            if (blinkTimer >= REVERSE_BLINK_MS)
            {
                ledState ^= 1;

                if (ledState)
                    HUB_LED_SetHigh();
                else
                    HUB_LED_SetLow();

                blinkTimer = 0;
            }
        }

        __delay_ms(10);
    }
}
